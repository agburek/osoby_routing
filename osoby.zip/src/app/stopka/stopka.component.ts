import { Component } from '@angular/core';

@Component({
  selector: 'app-stopka',
  standalone: true,
  imports: [],
  templateUrl: './stopka.component.html',
  styleUrl: './stopka.component.css'
})
export class StopkaComponent {

now = new Date();
year = this.now.getFullYear()

}
