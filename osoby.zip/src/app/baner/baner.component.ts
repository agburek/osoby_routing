import { Component } from '@angular/core';

@Component({
  selector: 'app-baner',
  standalone: true,
  imports: [],
  templateUrl: './baner.component.html',
  styleUrl: './baner.component.css'
})
export class BanerComponent {

}
