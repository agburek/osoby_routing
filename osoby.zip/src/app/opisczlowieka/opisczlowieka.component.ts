import { Component, inject } from '@angular/core';
import { ActivatedRoute, RouterLink, RouterModule } from '@angular/router';
import { OsobyService } from '../osoby.service';
import { Osoba } from '../osoba';

@Component({
  selector: 'app-opisczlowieka',
  standalone: true,
  imports: [RouterModule,RouterLink],
  templateUrl: './opisczlowieka.component.html',
  styleUrl: './opisczlowieka.component.css'
})
export class OpisczlowiekaComponent {
  route: ActivatedRoute = inject(ActivatedRoute);
  osobySerwis:OsobyService = inject(OsobyService);
  wybranaosoba:Osoba|undefined
  czlowiekId = -1;
  constructor(){
    this.czlowiekId = Number(this.route.snapshot.params['id'])
    this.wybranaosoba = this.osobySerwis.getOsobaById(this.czlowiekId)
  }
}

