import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OpisczlowiekaComponent } from './opisczlowieka.component';

describe('OpisczlowiekaComponent', () => {
  let component: OpisczlowiekaComponent;
  let fixture: ComponentFixture<OpisczlowiekaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [OpisczlowiekaComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OpisczlowiekaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
