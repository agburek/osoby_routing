import { Routes } from '@angular/router';
import { OsobyComponent } from './osoby/osoby.component';
import { OnasComponent } from './onas/onas.component';
import { BrakStronyComponent } from './brak-strony/brak-strony.component';
import { OpisczlowiekaComponent } from './opisczlowieka/opisczlowieka.component';


export const routes: Routes = [
   {path:"", component:OsobyComponent},
   {path:"osoby", component:OsobyComponent},
   {path:"onas", component:OnasComponent},
   {path:"osoby/:id", component:OpisczlowiekaComponent},
   {path:"**", component:BrakStronyComponent}
];
