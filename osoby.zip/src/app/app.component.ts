import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { OsobyComponent } from './osoby/osoby.component';
import { RouterModule } from '@angular/router';
import { BanerComponent } from "./baner/baner.component";
import { StopkaComponent } from "./stopka/stopka.component";
import { OnasComponent } from "./onas/onas.component";
import { BrakStronyComponent } from "./brak-strony/brak-strony.component";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, OsobyComponent, RouterModule, BanerComponent, StopkaComponent, OnasComponent, BrakStronyComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'osoby';
}
