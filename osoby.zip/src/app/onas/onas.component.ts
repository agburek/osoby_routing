import { Component } from '@angular/core';

@Component({
  selector: 'app-onas',
  standalone: true,
  imports: [],
  templateUrl: './onas.component.html',
  styleUrl: './onas.component.css'
})
export class OnasComponent {

}
