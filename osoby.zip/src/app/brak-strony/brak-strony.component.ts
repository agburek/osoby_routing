import { Component } from '@angular/core';

@Component({
  selector: 'app-brak-strony',
  standalone: true,
  imports: [],
  templateUrl: './brak-strony.component.html',
  styleUrl: './brak-strony.component.css'
})
export class BrakStronyComponent {

}
